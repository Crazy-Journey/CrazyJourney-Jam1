			 ______    __   __  _______  __   __    ______   _______  _     _  __    _ 
			|    _ |  |  | |  ||       ||  | |  |  |      | |       || | _ | ||  |  | |
			|   | ||  |  | |  ||  _____||  |_|  |  |  _    ||   _   || || || ||   |_| |
			|   |_||_ |  |_|  || |_____ |       |  | | |   ||  | |  ||       ||       |
			|    __  ||       ||_____  ||       |  | |_|   ||  |_|  ||       ||  _    |
			|   |  | ||       | _____| ||   _   |  |       ||       ||   _   || | |   |
			|___|  |_||_______||_______||__| |__|  |______| |_______||__| |__||_|  |__|

README

Rush Down is a two player competitive game where the objective is to reach the bottom of a well using elevators. Enemies drop coins and power, however they don't deal damage. The more power you have, the more hits from the other player you'll be able to take before dying and the more damage you'll deal both to enemies and your opponent. Coins are needed to pay for the elevator ride to the next floor. Enemies get progressively tougher to defeat in each floor! But they also award more coins and power. You can also shoot down into the next floor, attempting to kill some of those tougher enemies, or maybe trying to kill the other player, since they'll respawn on the previous floor, and they can't shoot up into earlier floors!

Farm power and wealth and Rush Down!

GIT

If you'd like to fork Rush Down or check its source code, feel free to do so! The Github repository link is:

	https://github.com/Crazy-Journey/CrazyJourney-Jam1


COLLABORATORS
The game was developed by Samuel García, Luis Parres and Joel Cabaco. It uses the following purchased assets from Game Dev Market:

- 8-Bit SFX Pack
- Arcade Item Pack
- Fantasy Forest Pixel Art Tileset
- Fantasy Medieval
- Game Collectable Pack Pixelart
- Golden Coin, Rotate Sequence
- Pixel Art Tileset Collection
- Pixelart Game Backgrounds
- Simple Pirate Characters
- Wil's Magic Pixel Particle Effect
- Zombie Characters

It also uses:
- 16x16 and animated lava tile (45 frames) - (https://opengameart.org/content/16x16-and-animated-lava-tile-45-frames)
- 8Bit Music - 062022 - (https://assetstore.unity.com/packages/audio/music/8bit-music-062022-225623)